import { Component, EventEmitter, Input, Output } from '@angular/core';
import { animate, animation, style, transition, trigger, useAnimation } from '@angular/animations';

interface SnackBar {
  message: string;
  action: string;
  type: string;
}

const showAnimation = animation([
  style({ transform: '{{transform}}', opacity: 0 }),
  animate('{{transition}}'),
]);

const hideAnimation = animation([
  animate('{{transition}}', style({ transform: '{{transform}}', opacity: 0 })),
]);

@Component({
  selector: 'app-snack-bar',
  templateUrl: './snack-bar.component.html',
  styleUrls: ['./snack-bar.component.scss'],
  animations: [
    trigger('panelState', [
      transition('void => visible', [useAnimation(showAnimation)]),
      transition('visible => void', [useAnimation(hideAnimation)]),
    ]),
  ]
})
export class SnackBarComponent {
  container: any;
  _visible: boolean = false;

  @Input() get visible(): boolean {
    return this._visible;
  }

  set visible(val) {
    this._visible = val;
    this.visibleChange.emit(this._visible);
    if(this._visible) this.autoClose();
  }

  @Input() data: SnackBar = {message: '', action: '', type: ''};
  @Input() hasAction = false;

  @Output() visibleChange: EventEmitter<any> = new EventEmitter();
  @Output() onAction: EventEmitter<any> = new EventEmitter();

  transformOptions: any = 'translate3d(-50%, 100%, 0px)';
  transitionOptions: string = '150ms cubic-bezier(0, 0, 0.2, 1)';

  constructor() { }

  action(): void {
    this.onAction.emit({});
    this.hide();
  }

  hide() {
    this.visibleChange.emit(false);
  }

  onAnimationStart(event: any) {
    if(event.toState === 'visible') {
      this.container = event.element;
      this.appendContainer();
    }
  }

  onAnimationEnd(event: any) {
    if(event.toState === 'void'){
      this.hide();
    }
  }

  appendContainer() {
    document.body.appendChild(this.container);
  }

  autoClose() {
    setTimeout(() => {
      this.hide();
    }, 3000);
  }
}
