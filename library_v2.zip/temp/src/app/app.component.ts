import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'sidebar';
  visible1 = false;
  visible2 = false;
  position = '';
  visible = false;

  showSnackBar1(){
    this.visible1 = true;
  }
  showSnackBar2(){
    this.visible2 = true;
  }

  actionClick(){
    console.log('Action clicked');
  }
}
